# TYNY 2019

Gulp сборка запускается стандартной командой gulp



Посмотреть сайт можно  [по ссылке](https://dvvinfo.github.io/test-tyny-2019/).


